/* ======================================================================

FUNCTION NAME: layerScroll()

PURPOSE: This function is used to create a scroll bar for use with both
Internet Explorer and Netscape Navigator browsers, so you can avoid 
seeing the normal window formatted scroll bars in IE. Netscape does not 
support scrolling a DIV element, so this function is required to maintain 
compatibility between both browser versions.

====================================================================== */

//Variables for scrolling functions
var engaged = false;
var mouseY = 0;
pageheight=null;
compLyr=eval(doc + '["slideLayer"]' + styl);
contentLyr=eval(doc + '["contentLayer"]' + styl);

function layerScroll(e) {
  mouseY = eval(ypos);
  if (engaged) {
    if (mouseY>5 && mouseY<590) {
      contentLyr.top= pageheight* -(mouseY/600)+20;
      compLyr.top=mouseY - 10;
 
    }
  }
}

/* ======================================================================

FUNCTION NAME: engageScroll()

PURPOSE: This function is used to set the variables for starting the
scrolling of the content layer.

====================================================================== */
function engageScroll(evt) {
  engaged=true;
  pageheight=(NS4)? document.contentLayer.document.height : document.all.contentLayer.clientHeight;

}

/* ======================================================================

FUNCTION NAME: endScroll()

PURPOSE: This function is used to end the scrolling process.

====================================================================== */
function endScroll(evt) {
  engaged=false;
}