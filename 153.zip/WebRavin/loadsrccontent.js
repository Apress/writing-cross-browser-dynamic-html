function loadGrkContent(doc_url) {
   if (IE4) {
contentGT.width= 238;
document.all.ieContent.document.frames["ieframe'].document.location.href = doc_url;
   } else if(NS4) {
      contentGT.load(doc_url, 238);
   }
}
