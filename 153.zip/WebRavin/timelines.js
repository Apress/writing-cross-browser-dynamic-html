function MM_initTimelines() {
    //MM_initTimelines() Copyright 1997 Macromedia, Inc. All rights reserved.
    var ns = navigator.appName == "Netscape";
    document.MM_Time = new Array(1);
    document.MM_Time[0] = new Array(16);
    document.MM_Time["Timeline1"] = document.MM_Time[0];
    document.MM_Time[0].MM_Name = "Timeline1";
    document.MM_Time[0].fps = 15;
    document.MM_Time[0][0] = new String("sprite");
    document.MM_Time[0][0].slot = 1;
    if (ns)
        document.MM_Time[0][0].obj = document.Layer2;
    else
        document.MM_Time[0][0].obj = document.all ? document.all["Layer2"] : null;
    document.MM_Time[0][0].keyFrames = new Array(1, 20, 35, 45, 60);
    document.MM_Time[0][0].values = new Array(2);
    document.MM_Time[0][0].values[0] = new Array(10,43,77,110,144,177,210,244,277,310,344,376,408,440,471,501,531,560,589,617,590,558,528,498,469,441,413,386,360,334,308,282,257,232,209,239,272,304,336,367,398,431,465,501,529,501,471,440,408,376,342,308,273,237,202,166,130,95,59,24);
    document.MM_Time[0][0].values[0].prop = "left";
    document.MM_Time[0][0].values[1] = new Array(12,14,16,18,20,22,24,26,28,30,32,34,37,39,41,43,46,49,52,58,67,70,73,75,77,79,81,83,85,87,90,92,95,99,106,119,125,131,136,140,145,150,156,164,182,193,201,207,213,219,225,230,235,241,246,251,256,261,266,272);
    document.MM_Time[0][0].values[1].prop = "top";
    if (!ns) {
        document.MM_Time[0][0].values[0].prop2 = "style";
        document.MM_Time[0][0].values[1].prop2 = "style";
    }
    document.MM_Time[0][1] = new String("behavior");
    document.MM_Time[0][1].frame = 72;
    document.MM_Time[0][1].value = "MM_changeProp('document.layers[\\\'Refs\\\']','document.all[\\\'Refs\\\']','style.visibility','visible','LAYER');MM_changeProp('document.layers[\\\'Refs\\\']','document.all[\\\'Refs\\\']','visibility','visible','LAYER')";
    document.MM_Time[0][2] = new String("sprite");
    document.MM_Time[0][2].slot = 2;
    if (ns)
        document.MM_Time[0][2].obj = document.Xplat;
    else
        document.MM_Time[0][2].obj = document.all ? document.all["Xplat"] : null;
    document.MM_Time[0][2].keyFrames = new Array(76, 79, 86);
    document.MM_Time[0][2].values = new Array(4);
    document.MM_Time[0][2].values[0] = new Array(511,480,450,432,451,474,500,527,554,582,609);
    document.MM_Time[0][2].values[0].prop = "left";
    document.MM_Time[0][2].values[1] = new Array(350,328,304,267,253,242,233,224,216,208,199);
    document.MM_Time[0][2].values[1].prop = "top";
    if (!ns) {
        document.MM_Time[0][2].values[0].prop2 = "style";
        document.MM_Time[0][2].values[1].prop2 = "style";
    }
    document.MM_Time[0][2].values[2] = new Array(182,184,186,188,183,178,173,168,163,158,154);
    document.MM_Time[0][2].values[2].prop = "width";
    if (!ns)
        document.MM_Time[0][2].values[2].prop2 = "style";
    document.MM_Time[0][2].values[3] = new Array(71,71,71,71,64,58,52,45,39,33,27);
    document.MM_Time[0][2].values[3].prop = "height";
    if (!ns)
        document.MM_Time[0][2].values[3].prop2 = "style";
    document.MM_Time[0][3] = new String("behavior");
    document.MM_Time[0][3].frame = 51;
    document.MM_Time[0][3].value = "MM_swapImage('document.layers[\\\'Layer2\\\'].document.roseship','document.roseship','images/roseship.gif','MM_swapImage5')";
    document.MM_Time[0][4] = new String("behavior");
    document.MM_Time[0][4].frame = 20;
    document.MM_Time[0][4].value = "MM_swapImage('document.layers[\\\'Layer2\\\'].document.roseship','document.roseship','images/roseshipr.gif','MM_swapImage1')";
    document.MM_Time[0][5] = new String("behavior");
    document.MM_Time[0][5].frame = 35;
    document.MM_Time[0][5].value = "MM_swapImage('document.layers[\\\'Layer2\\\'].document.roseship','document.roseship','images/roseship.gif','MM_swapImage2')";
    document.MM_Time[0][6] = new String("behavior");
    document.MM_Time[0][6].frame = 45;
    document.MM_Time[0][6].value = "MM_swapImage('document.layers[\\\'Layer2\\\'].document.roseship','document.roseship','images/roseshipr.gif','MM_swapImage3')";
    document.MM_Time[0][7] = new String("behavior");
    document.MM_Time[0][7].frame = 60;
    document.MM_Time[0][7].value = "MM_swapImage('document.layers[\\\'Layer2\\\'].document.roseship','document.roseship','images/roseship.gif','MM_swapImage4');MM_changeProp('document.layers[\\\'Layer1\\\']','document.all[\\\'Layer1\\\']','style.visibility','visible','LAYER');MM_changeProp('document.layers[\\\'Layer1\\\']','document.all[\\\'Layer1\\\']','visibility','visible','LAYER')";
    document.MM_Time[0][8] = new String("behavior");
    document.MM_Time[0][8].frame = 65;
    document.MM_Time[0][8].value = "MM_swapImage('document.layers[\\\'chestlayer\\\'].document.chest','document.chest','images/chest2.gif','MM_swapImage9')";
    document.MM_Time[0][9] = new String("behavior");
    document.MM_Time[0][9].frame = 70;
    document.MM_Time[0][9].value = "MM_swapImage('document.layers[\\\'chestlayer\\\'].document.chest','document.chest','images/chest3.gif','MM_swapImage10')";
    document.MM_Time[0][10] = new String("behavior");
    document.MM_Time[0][10].frame = 76;
    document.MM_Time[0][10].value = "MM_changeProp('document.layers[\\\'Xplat\\\']','document.all[\\\'Xplat\\\']','style.visibility','visible','LAYER');MM_changeProp('document.layers[\\\'Xplat\\\']','document.all[\\\'Xplat\\\']','visibility','visible','LAYER')";
    document.MM_Time[0][11] = new String("sprite");
    document.MM_Time[0][11].slot = 1;
    if (ns)
        document.MM_Time[0][11].obj = document.Multimedia;
    else
        document.MM_Time[0][11].obj = document.all ? document.all["Multimedia"] : null;
    document.MM_Time[0][11].keyFrames = new Array(80, 83, 90);
    document.MM_Time[0][11].values = new Array(6);
    document.MM_Time[0][11].values[0] = new Array(514,486,458,444,460,480,503,529,555,582,608);
    document.MM_Time[0][11].values[0].prop = "left";
    document.MM_Time[0][11].values[1] = new Array(355,336,316,279,259,241,224,206,188,170,152);
    document.MM_Time[0][11].values[1].prop = "top";
    if (!ns) {
        document.MM_Time[0][11].values[0].prop2 = "style";
        document.MM_Time[0][11].values[1].prop2 = "style";
    }
    document.MM_Time[0][11].values[2] = new Array(121,121,121,121,121,121,121,121,121,121,121);
    document.MM_Time[0][11].values[2].prop = "width";
    if (!ns)
        document.MM_Time[0][11].values[2].prop2 = "style";
    document.MM_Time[0][11].values[3] = new Array(0,0,0,0,0,0,0,0,0,0,0);
    document.MM_Time[0][11].values[3].prop = "height";
    if (!ns)
        document.MM_Time[0][11].values[3].prop2 = "style";
    document.MM_Time[0][11].values[4] = new Array("inherit","inherit","inherit");
    document.MM_Time[0][11].values[4].prop = "visibility";
    if (!ns)
        document.MM_Time[0][11].values[4].prop2 = "style";
    document.MM_Time[0][11].values[5] = new Array("0","0","0");
    document.MM_Time[0][11].values[5].prop = "zIndex";
    if (!ns)
        document.MM_Time[0][11].values[5].prop2 = "style";
    document.MM_Time[0][12] = new String("sprite");
    document.MM_Time[0][12].slot = 3;
    if (ns)
        document.MM_Time[0][12].obj = document.Refs;
    else
        document.MM_Time[0][12].obj = document.all ? document.all["Refs"] : null;
    document.MM_Time[0][12].keyFrames = new Array(72, 77, 81);
    document.MM_Time[0][12].values = new Array(3);
    document.MM_Time[0][12].values[0] = new Array(507,482,457,433,410,402,438,487,541,594);
    document.MM_Time[0][12].values[0].prop = "left";
    document.MM_Time[0][12].values[1] = new Array(357,336,316,295,268,233,192,158,125,93);
    document.MM_Time[0][12].values[1].prop = "top";
    if (!ns) {
        document.MM_Time[0][12].values[0].prop2 = "style";
        document.MM_Time[0][12].values[1].prop2 = "style";
    }
    document.MM_Time[0][12].values[2] = new Array(71,71,71,71,71,71,60,50,40,30);
    document.MM_Time[0][12].values[2].prop = "height";
    if (!ns)
        document.MM_Time[0][12].values[2].prop2 = "style";
    document.MM_Time[0][13] = new String("behavior");
    document.MM_Time[0][13].frame = 80;
    document.MM_Time[0][13].value = "MM_changeProp('document.layers[\\\'Multimedia\\\']','document.all[\\\'Multimedia\\\']','style.visibility','visible','LAYER');MM_changeProp('document.layers[\\\'Multimedia\\\']','document.all[\\\'Multimedia\\\']','top','visible','LAYER')";
    document.MM_Time[0][14] = new String("sprite");
    document.MM_Time[0][14].slot = 3;
    if (ns)
        document.MM_Time[0][14].obj = document.Info;
    else
        document.MM_Time[0][14].obj = document.all ? document.all["Info"] : null;
    document.MM_Time[0][14].keyFrames = new Array(87, 90, 93);
    document.MM_Time[0][14].values = new Array(6);
    document.MM_Time[0][14].values[0] = new Array(505,489,474,470,506,549,592);
    document.MM_Time[0][14].values[0].prop = "left";
    document.MM_Time[0][14].values[1] = new Array(352,330,308,279,265,259,253);
    document.MM_Time[0][14].values[1].prop = "top";
    if (!ns) {
        document.MM_Time[0][14].values[0].prop2 = "style";
        document.MM_Time[0][14].values[1].prop2 = "style";
    }
    document.MM_Time[0][14].values[2] = new Array(0,18,36,54,69,84,100);
    document.MM_Time[0][14].values[2].prop = "width";
    if (!ns)
        document.MM_Time[0][14].values[2].prop2 = "style";
    document.MM_Time[0][14].values[3] = new Array(0,22,44,66,57,48,39);
    document.MM_Time[0][14].values[3].prop = "height";
    if (!ns)
        document.MM_Time[0][14].values[3].prop2 = "style";
    document.MM_Time[0][14].values[4] = new Array("visible","visible","visible");
    document.MM_Time[0][14].values[4].prop = "visibility";
    if (!ns)
        document.MM_Time[0][14].values[4].prop2 = "style";
    document.MM_Time[0][14].values[5] = new Array("0","0","0");
    document.MM_Time[0][14].values[5].prop = "zIndex";
    if (!ns)
        document.MM_Time[0][14].values[5].prop2 = "style";
    document.MM_Time[0][15] = new String("behavior");
    document.MM_Time[0][15].frame = 87;
    document.MM_Time[0][15].value = "MM_changeProp('document.layers[\\\'Info\\\']','document.all[\\\'Info\\\']','style.visibility','visible','LAYER');MM_changeProp('document.layers[\\\'Info\\\']','document.all[\\\'Info\\\']','visibility','visible','LAYER')";
    document.MM_Time[0].lastFrame = 93;
    for (i=0; i<document.MM_Time.length; i++) {
        document.MM_Time[i].ID = null;
        document.MM_Time[i].curFrame = 0;
        document.MM_Time[i].delay = 1000/document.MM_Time[i].fps;
    }
}


function MM_timelinePlay(tmLnName, myID) { //v1.2
  //Copyright 1997 Macromedia, Inc. All rights reserved.
  var i,j,tmLn,props,keyFrm,sprite,numKeyFr,firstKeyFr,propNum,theObj,firstTime=false;
  if (document.MM_Time == null) MM_initTimelines(); //if *very* 1st time
  tmLn = document.MM_Time[tmLnName];
  if (myID == null) { myID = ++tmLn.ID; firstTime=true;}//if new call, incr ID
  if (myID == tmLn.ID) { //if Im newest
    setTimeout('MM_timelinePlay("'+tmLnName+'",'+myID+')',tmLn.delay);
    fNew = ++tmLn.curFrame;
    for (i=0; i<tmLn.length; i++) {
      sprite = tmLn[i];
      if (sprite.charAt(0) == 's') {
        if (sprite.obj) {
          numKeyFr = sprite.keyFrames.length; firstKeyFr = sprite.keyFrames[0];
          if (fNew >= firstKeyFr && fNew <= sprite.keyFrames[numKeyFr-1]) {//in range
            keyFrm=1;
            for (j=0; j<sprite.values.length; j++) {
              props = sprite.values[j]; 
              if (numKeyFr != props.length) {
                if (props.prop2 == null) sprite.obj[props.prop] = props[fNew-firstKeyFr];
                else        sprite.obj[props.prop2][props.prop] = props[fNew-firstKeyFr];
              } else {
                while (keyFrm<numKeyFr && fNew>=sprite.keyFrames[keyFrm]) keyFrm++;
                if (firstTime || fNew==sprite.keyFrames[keyFrm-1]) {
                  if (props.prop2 == null) sprite.obj[props.prop] = props[keyFrm-1];
                  else        sprite.obj[props.prop2][props.prop] = props[keyFrm-1];
        } } } } }
      } else if (sprite.charAt(0)=='b' && fNew == sprite.frame) eval(sprite.value);
      if (fNew > tmLn.lastFrame) tmLn.ID = 0;
  } }
}

function MM_preloadImages() { //v1.2
  if (document.images) {
    var imgFiles = MM_preloadImages.arguments;
    var preloadArray = new Array();
    for (var i=0; i<imgFiles.length; i++) {
      preloadArray[i] = new Image;
      preloadArray[i].src = imgFiles[i];
    }
  }
}

function MM_swapImage() { //v1.2
  var i,j=0,objStr,obj,swapArray=new Array,oldArray=document.MM_swapImgData;
  for (i=0; i < (MM_swapImage.arguments.length-2); i+=3) {
    objStr = MM_swapImage.arguments[(navigator.appName == 'Netscape')?i:i+1];
    if ((objStr.indexOf('document.layers[')==0 && document.layers==null) ||
        (objStr.indexOf('document.all[')   ==0 && document.all   ==null))
      objStr = 'document'+objStr.substring(objStr.lastIndexOf('.'),objStr.length);
    obj = eval(objStr);
    if (obj != null) {
      swapArray[j++] = obj;
      swapArray[j++] = (oldArray==null || oldArray[j-1]!=obj)?obj.src:oldArray[j];
      obj.src = MM_swapImage.arguments[i+2];
  } }
  document.MM_swapImgData = swapArray; //used for restore
}