/* ======================================================================
FUNCTION:	DetermineCurrentBrowser 
 
INPUT: 		none.

RETURN:		a string indicating the current browser

DESC:			This function is used with client-side JavaScript to detect
				the brand and version of the user's browser.  Detects only
				Netscape and Microsoft browsers.  Returns "Other" if a different
				brand is detected.

PLATFORMS:	Netscape Navigator 3.01 and higher,
			  	Microsoft Internet Explorer 3.02 and higher,
====================================================================== */
function DetermineCurrentBrowser() {
	var bwr = navigator.userAgent.toLowerCase(); 
	var ver = parseInt(navigator.appVersion); 
	
   this.ns  = ((agent.indexOf('mozilla')!=-1) && 
              ((agent.indexOf('spoofer')==-1) && 
              (agent.indexOf('compatible') == -1)));
   this.ns4 = (this.ns && (this.ver >= 4));
   this.ie = (bwr.indexOf("msie") !=-1);
   this.ie4 = (this.ie && (this.ver >=4));
   
} // end DetermineCurrentBrowser

var ua = new DeterminCurrentBrowser();

if(ua.ns4) {
   doc = "document";
   sty = "";
   htm = ".document";
   xpos = "e.pageX"
   ypos = "e.pageY";
   }
 else if(ua.ie4) {
   doc = "document.all";
   sty = ".style";
   htm = "";
   xpos = "event.x"
   ypos = "event.y";
   }

