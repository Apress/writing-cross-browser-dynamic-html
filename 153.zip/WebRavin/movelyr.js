var engaged = false
var offsetX = 0
var offsetY = 0

function dragIt(e) {
   engaged = true;
   if (IE4) { //Fix IE's left and top properties for use as integer
     leftPos = movingLyr.left;
     topPos = movingLyr.top;
     chkLeftLength = leftPos.length; //Get length of left setting
     chkTopLength = leftPos.length;  //Get length of top setting
     if (chkLeftLength !== -1) { //Set offset to integer portion of .left
        offsetX = eval(xpos) - leftPos.substring(0,chkLeftLength-2); 
     }
     if (chkLeftLength !== -1) { //Set offset to integer portion of .top
        offsetY = eval(ypos) - topPos.substring(0,chkTopLength-2);
     }
   } else if (NS4) { //NS already uses integers.
  	    offsetX = eval(xpos) - movingLyr.left;
	    offsetY = eval(ypos) - movingLyr.top;
   }
   if (engaged) {
     for (var i=0; i<400; i++) {
      moveIt(e);
      }
      offsetX=0;
      offsetY=0;
      engaged = false
	}
}
function moveIt(e)   {
	   movingLyr.top = eval(ypos) + offsetY;
      movingLyr.left = eval(xpos) + offsetX;
      offsetX--;
      offsetY--;
      t = setInterval("moveIt()",500);
}
