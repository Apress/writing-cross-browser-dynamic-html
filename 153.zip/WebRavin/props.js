/* ======================================================================

     JavaScript Source File -- Created with NetObjects ScriptBuilder

NAME: props.js

AUTHOR: Heather Williamson

PURPOSE: control Property Values

====================================================================== */
function MM_changeProp(objStrNS,objStrIE,theProp,theValue) { //v1.2
  var NS = (navigator.appName == 'Netscape');
  var objStr = (NS)?objStrNS:objStrIE;
  if (( NS && (objStr.indexOf('document.layers[')!=0 || document.layers!=null)) ||
      (!NS && (objStr.indexOf('document.all[')   !=0 || document.all   !=null))) {
    var obj = eval(objStr);
    if ((obj != null) && (theProp.indexOf("style.") != 0 || obj.style != null)) {
      eval(objStr+'.'+theProp + '="'+theValue+'"');
  } }
}

function MM_preloadImages() { //v1.2
  if (document.images) {
    var imgFiles = MM_preloadImages.arguments;
    var preloadArray = new Array();
    for (var i=0; i<imgFiles.length; i++) {
      preloadArray[i] = new Image;
      preloadArray[i].src = imgFiles[i];
    }
  }
}

function MM_swapImage() { //v1.2
  var i,j=0,objStr,obj,swapArray=new Array,oldArray=document.MM_swapImgData;
  for (i=0; i < (MM_swapImage.arguments.length-2); i+=3) {
    objStr = MM_swapImage.arguments[(navigator.appName == 'Netscape')?i:i+1];
    if ((objStr.indexOf('document.layers[')==0 && document.layers==null) ||
        (objStr.indexOf('document.all[')   ==0 && document.all   ==null))
      objStr = 'document'+objStr.substring(objStr.lastIndexOf('.'),objStr.length);
    obj = eval(objStr);
    if (obj != null) {
      swapArray[j++] = obj;
      swapArray[j++] = (oldArray==null || oldArray[j-1]!=obj)?obj.src:oldArray[j];
      obj.src = MM_swapImage.arguments[i+2];
  } }
  document.MM_swapImgData = swapArray; //used for restore
}