function showStatusMessage(messageStr) { 
  window.status=messageStr;
  }
