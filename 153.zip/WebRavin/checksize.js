function checksizeNS ()   {
   if (avail_Width < 640) && (avail_Height < 480)  {
/* If screen is 640x480 or smaller, use smaller images listed below*/
      document['ZeusImg'].src = "images/zeussmall.gif";
      document['GreekImg'].src = "images/greeksmall.gif";   
      document['HermesImg'].src = "images/hermessmall.gif";
/* This has to be done for all images on the page. */
   }
}
function checksizeIE ()   {
   if (avail_Width < 460) && (avail_Height < 600)  {
      document.all['ZeusImg'].src = "images/zeussmall.gif";
      document.all['GreekImg'].src = "images/greeksmall.gif";   
      document.all['HermesImg'].src = "images/hermessmall.gif";
   }
}
