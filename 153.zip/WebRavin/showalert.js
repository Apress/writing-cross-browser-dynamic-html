function popupMsg(theMessage) { 
  alert(theMessage);
}
