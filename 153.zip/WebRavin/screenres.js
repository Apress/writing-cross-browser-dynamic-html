if ns4 {
   avail_width =  innerWidth;
   avail_height = innerHeight; 
} else ie4 {
   avail_width = document.body.clientWidth;
   avail_height = document.body.clientHeight;
}