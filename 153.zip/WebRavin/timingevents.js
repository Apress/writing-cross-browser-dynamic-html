var timeArray = new Array(5);

function setTiming(timeFrame, fctnName)
   this.timeFrame = timeFrame;
   this.fctnName = fctnName;
}

timingArray = new Array(5)
timingArray[0] = new setTiming("1", "changeProp('zeuslayer','visible','visible')");
timingArray[1] = new setTiming("4", "changeProp('greektext','visible','visible')");
timingArray[2] = new setTiming("10", "changeProp('hermeslayer','visible','visible')");
timingArray[3] = new setTiming("15", "dragIt(event)");
timingArray[4] = new setTiming("19", "swapImage('hermeslayer','1')");


arraystep = 0;
arraylength = timingArray.length;

function startTimer() {
  for (timecount=0; timecount<30; timecount++){
    alert('current time: ' + timecount);
    if (timingArray[arraystep].timeFrame == timecount) {
      alert ('Array step: ' + arraystep);
      eval(timingArray[arraystep].fctnName);
      if (arraystep == (arraylength-1)) {
        timecount=30;
      } else {
        arraystep++;
      }
    }
    t=setInterval("startTimer()",100);
  }
}