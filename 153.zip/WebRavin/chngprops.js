function changeProp(layerName,theProp,theValue) { 
   var usedLyr = eval(doc + '["' + layerName + '"]' + styl);
if  ((theProp == "visibile") || (theProp == "visibility")) {
   if (NS4) {
      theProp = "visible";
   }
   else if (IE4) {
      theProp = "visibility";
   }
}
   eval('usedLyr.' + theProp + '="' + theValue + '"');
  }
