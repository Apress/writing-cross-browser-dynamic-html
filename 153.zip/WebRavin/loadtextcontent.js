function loadBblContent(newText,layerName) {
   contentBubble = eval (doc + '["' + layerName + '"]' +html);
   if (NS4) {
      contentBubble.write(newText);
      contentBubble.close();
   else {
      contentBubble.innerHTML = newText;
   }
}
