function controlSound(sndAction,sndObj) { 
  if (eval(sndObj) != null) {
    if (NS4) eval(sndObj+((sndAction=='stop')?'.stop()':'.play(false)'));
    else if (eval(sndObj+".FileName")) 
     eval(sndObj+((sndAction=='stop')?'.stop()':'.run()'));
  }
}
