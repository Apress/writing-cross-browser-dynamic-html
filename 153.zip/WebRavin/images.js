/* ======================================================================

NAME: images.js

AUTHOR: Heather Williamson

PURPOSE: Functions: swapImage 
     -- Sets the Images that are used when the mouse is 
     ran over, off of, or clicked on one of the menu buttons.

====================================================================== */

function swapImage(imgName,newImg){
//Defines the function and its parameters (the name of the image as 
//given in the NAME attribute of the IMG tag, and the new SRC filename).

        if ((navigator.appName == 'Netscape' && parseFloat(navigator.appVersion) >= 3) || (parseFloat(navigator.appVersion) >= 4)){
        //Checks that the browser is Netscape and the version number is 3 or 
        //greater OR that the version number is greater than or equal to 4 (the
        //ability to access and change the SRC property became available 
        //with version 3.0 of Netscape and version 4.0 of Internet Explorer).
        //JavaScript's built-in parseFloat() function converts the appVersion
        //string (for example, "3.0 (Macintosh; I; PPC)") to a number ("3.0").
                
                eval('document.' + imgName + '.src = "' + newImg + '"');
                //JavaScript's built-in eval() function inserts values for variables,
                //concatenates strings, and interprets the results. For example, if the 
                //user rolls over the "arts" button, the contents of the parentheses will
                //evaluate to document.arts.src="arts_highlight.gif".
        }
}


/* ======================================================================

  Functions: loadText
     Loads the specified HTML file into the content layer Layer1
     when one of the menu options are selected.
 
====================================================================== */

function loadText(textName) {
  if(ua.ns4) {
      document.contentLayer.write (textName);
		document.contentLayer.close();
     }
  else {
      contentLayer.innerHTML = textName;
     }
}
