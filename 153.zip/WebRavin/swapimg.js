var preloadArray = New Array();
function swapImage(imgName,arrayID) {
  if (document.images) {
   if(IE4){
     workingImg = eval(doc + '["' + imgName + '"]');
     workingImg.src = preloadArray[arrayID].src;
   } else if (NS4) {
     document[imgName].src = preloadArray[arrayID].src;
     }
 }
}
