/* ======================================================================

GLOBAL VARIABLES

PURPOSE: To set all variables that are used by multiple functions

====================================================================== */
//Variables for image array functions
var preloadArray = new Array();

//Original setup for scrolling function object identification

/* ======================================================================

FUNCTION NAME: preloadImages()

PURPOSE: To preload all images used on the site interface into an array 
so that they can be reference by an index number from the swapImage()
function.

====================================================================== */
function preloadImages() { 
  if (document.images) {
    var imgFiles = preloadImages.arguments;
    for (var i=0; i<imgFiles.length; i++) {
      preloadArray[i] = new Image;
      preloadArray[i].src = imgFiles[i];
    }
  }
}


/* ======================================================================

FUNCTION NAME: swapImages()

PURPOSE: To swap images that have been preloaded into the document
using the preloadImages() function.

====================================================================== */
function swapImage(layerName,imgName,arrayID) {
  if (document.images) {
   if(IE4){
     workingImg = eval(doc + '["' + imgName + '"]');
     workingImg.src = preloadArray[arrayID].src;
   } else if (NS4) {
     document[layerName].document[imgName].src = preloadArray[arrayID].src;
     }
 }
}

/* ======================================================================

FUNCTION NAME: setTiming()

PURPOSE: To assign values to the timingArray. Each event entered into
the array has to be in its timing order. Getting these events out of order
will cause the script to loop indefinitly.

====================================================================== */
function setTiming(timeFrame, fctnName) {
   this.timeFrame = timeFrame;
   this.fctnName = fctnName;
}
var timingArray = new Array()
timingArray[0] = new setTiming("1", "swapImage('shipLayer','roseship','0')");
timingArray[1] = new setTiming("4", "moveLayer('shipLayer','10,61,112,163,214,265,314,360,404,445','12,19,25,32,38,45,52,60,69,83')");
timingArray[2] = new setTiming("6", "swapImage('shipLayer','roseship','1')");
timingArray[3] = new setTiming("8", "moveLayer('shipLayer','424,394,365,338,312,286,259,233,206,184','102,111,118,124,130,136,142,149,157,172')");
timingArray[4] = new setTiming("10", "swapImage('shipLayer','roseship','0')");
timingArray[5] = new setTiming("14", "moveLayer('shipLayer','210,240,270,300,331,362,395,430,466,497','184,191,196,200,205,209,213,218,224,237')");
timingArray[6] = new setTiming("16", "swapImage('shipLayer','roseship','1')");
timingArray[7] = new setTiming("20", "moveLayer('shipLayer','455,410,364,315,266,215,164,113,62,11','245,249,253,256,258,261,263,266,268,271')");
timingArray[8] = new setTiming("22", "swapImage('shipLayer','roseship','0')");
timingArray[9] = new setTiming("26", "changeProp('contentLayer', 'visibility', 'visible')");
timingArray[10] = new setTiming("35", "swapImage('chestlayer','chest','4')");
timingArray[11] = new setTiming("40", "swapImage('chestlayer','chest','5')");
timingArray[12] = new setTiming("50", "changeProp('Xplat', 'visibility', 'visible')");
timingArray[13] = new setTiming("55", "moveLayer('Xplat','511,514,517,520,524,527,530,533,536,539,542,546,549,552,555','350,338,326,315,303,291,279,267,256,233,210,190,175,160,145')");
timingArray[14] = new setTiming("60", "changeProp('Refs', 'visibility', 'visible')");
timingArray[15] = new setTiming("65", "moveLayer('Refs','507,508,509,510,512,513,514,516,518,520,522,524,526,528,530','409,389,370,350,330,310,291,271,251,232,200,170,140,110,80')");
timingArray[16] = new setTiming("70", "changeProp('Multimedia', 'visibility', 'visible')");
timingArray[17] = new setTiming("75", "moveLayer('Multimedia','514,518,523,527,531,536,540,545,549,553,558,562,566,571,575','363,354,344,335,326,316,307,295,280,270,255,245,235,225,215')");
timingArray[18] = new setTiming("80", "changeProp('Info', 'visibility', 'visible')");
timingArray[19] = new setTiming("85", "moveLayer('Info','509,512,515,518,521,524,527,530,532,535,538,541,544,547,550','358,353,348,342,337,332,327,322,316,308,300,292,285,277,270')");
/* ======================================================================

FUNCTION NAME: startTimer()

PURPOSE: To start the timer, to run through the list of events that 
occur on this page. This function compares the current timer setting, 
the time value in the array, if they match, then the script runs the event.
If they don't match, the script continues timing until they do. This 
function uses an if statement tied to a setTimeout loop to provide an 
system of checks for  ensuring that the timer does not inadvertantly 
keep running forever. 

====================================================================== */

//Variables for Timing Functions
arraystep = 0;
arraylength = timingArray.length;
timecount = 0;

function startTimer() {
 if (timecount<=100) {
    if (timingArray[arraystep].timeFrame == timecount) {
      eval(timingArray[arraystep].fctnName);
      if (arraystep == (arraylength-1)) {
        timecount=85;
      } else {
        arraystep++;
      }
	} 
	timecount++;
	setTimeout("startTimer()",100);
  }  
  }

/* ======================================================================

FUNCTION NAME: changeProp()

PURPOSE: This function can be used to change the basic properties of
layers and images found within the HTML document.
====================================================================== */
function changeProp(layerName,theProp,theValue) { 
   var usedLyr = eval(doc + '["' + layerName + '"]' + styl);
   eval('usedLyr.' + theProp + '="' + theValue + '"');
}

/* ======================================================================

FUNCTION NAME: moveLayer()

PURPOSE: This function can be used to move an identified layer from
point A to point B, through the given list of Top and left position
markers. The nuumber of arguments passed to the top array and the left 
array should be the same.

====================================================================== */

function moveLayer(layerName, leftList, topList) {
  movingLyr = eval(doc + '["' + layerName + '"]' + styl);
 
  var topArray = topList.split(",");
  var leftArray = leftList.split(",");
  var i=0;
  for (var i=0;i<topArray.length;i++) {
      movingLyr.top = topArray[i];
      movingLyr.left = leftArray[i];
  }
}

/* ======================================================================

FUNCTION NAME: loadContent()

PURPOSE: This function is used to load information into the layer located
in the middle of our screen. Since IE does not allow you to reference the
contents of a DIV element through the src element, you have to have a 
seperate 'iframe' that can contain the contents since you can reference
the contents of an 'iframe' with the src attribute. Netscape allows you
to reference the contents of any layer with the src. 

====================================================================== */
function loadContent(docurl) {
  if (IE4) {
    parent.bufferFrame.location = docurl;
  } else if(NS4) {
    document.contentLayer.load(docurl, 400);
  }
}

/* ======================================================================

FUNCTION NAME: finishIEload()

PURPOSE: This function is used to load information into the DIV object 
located in the middle of our screen. Since IE does not allow you to 
reference the contents of a DIV element through the src element, we 
originally load each new document into the hidden IFRAME, then at the 
top of each external document we create, we run this script to test the 
completed load procedure, and then copy the text into the DIV using the
innerHTML commands supported by Internet Explorer.

====================================================================== */
function finishIEload() {
  if (IE4) {
   contentLayer.innerHTML = parent.bufferFrame.document.body.innerHTML
  }
}

