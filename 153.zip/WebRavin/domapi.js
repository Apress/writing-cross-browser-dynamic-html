   if (NS4) {
      doc = "document";
      styl = "";
    html = ".document";
    xpos =  "e.pageX";
    ypos =  "e.pageY";
   }
   else if (IE4) {
      doc = "document.all";
      styl = ".style";
      html = "";
      xpos =  "event.x";
      ypos =  "event.y";
   }
