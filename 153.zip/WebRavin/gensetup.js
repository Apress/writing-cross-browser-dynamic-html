/* ======================================================================
FUNCTION:	Ua
 
INPUT: 		none.

RETURN:		a string indicating the current browser

DESC:			This function is used with client-side JavaScript to detect
				the brand and version of the user's browser.  Detects only
				Netscape and Microsoft browsers.  Returns "Other" if a different
				brand is detected.

PLATFORMS:	Netscape Navigator 3.01 and higher,
			  	Microsoft Internet Explorer 3.02 and higher,
====================================================================== */
function Ua() {
	var bwr = navigator.userAgent.toLowerCase(); 
	this.ver = parseInt(navigator.appVersion); 
	
   this.ns  = ((bwr.indexOf('mozilla')!=-1) && 
              ((bwr.indexOf('spoofer')==-1) && 
              (bwr.indexOf('compatible') == -1)));
   this.ns4 = (this.ns && (this.ver >= 4));
   this.ie = (bwr.indexOf("msie") !=-1);
   this.ie4 = (this.ie && (this.ver >=4));
   
} 
// end Ua

var ua = new Ua();
var contentLayer = eval(doc + '["Layer1"]' + htm);

if(ua.ns4) {
   doc = "document";
   sty = "";
   htm = ".document";
   xpos = "e.pageX";
   ypos = "e.pageY";
   }
 else if(ua.ie4) {
   doc = "document.all";
   sty = ".style";
   htm = "";
   xpos = "event.x";
   ypos = "event.y";
   }

function onerror() {
    document.location.href="javascript:";
}

